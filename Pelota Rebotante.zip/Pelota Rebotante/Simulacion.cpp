#include "Simulacion.h"

//Constructor: Acepta como par�metros la dimension y el nombre de la ventana para el programa. Inicializa las variables y
//llama a m�todos de inicializaci�n
Simulacion::Simulacion(Vector2i dimensiones_programa, string nombre_programa) {

	//Iguala la variable de vector de dimension
	dimensiones_ventana = dimensiones_programa;

	//Iguala la variable de nombre
	nombre_ventana = nombre_programa;

	//Asigna una nueva ventana a la variable existente
	ventana = crearVentana(dimensiones_ventana.x, dimensiones_ventana.y, nombre_ventana);

	//Instancia el gestor de eventos
	gestor_eventos = new Event;

	//Fija las dimensiones de los cuerpos a crear
	dimensiones_suelo = {18.0f, 1.0f};
	dimensiones_pared = { 1.0f, 9.0f };

	//Radio en metros de la bola
	radio_bola = 1;

	//Llama a la creaci�n de la parte f�sica de los cuerpos
	crearFisicas();

	//Llama a la creaci�n de la parte visual de los cuerpos
	crearVisuales();

	//coloca los objetos en las posiciones deseadas
	reposicionarObjeto(cuerpo_suelo, {18.0f, 18.0f});
	reposicionarObjeto(cuerpo_bola, {20.0f, 2.0f});
	reposicionarObjeto(cuerpo_pared[0], {1.0f, 10.0f});
	reposicionarObjeto(cuerpo_pared[1], {37.0f, 10.0f});

	aplicarFuerza(cuerpo_bola, { 1.0f, 0.0f }, {0.0f, 0.0f});

}

//M�todo que permite aplicar una fuerza lineal al cuerpo suministrado por par�metro, usando el valor
void Simulacion::aplicarFuerza(b2Body* cuerpo, b2Vec2 valor, b2Vec2 punto_origen) {

	//Se aplica el impulso lineal (valor) al cuerpo en el punto de origen elegido, despertandolo si est� dormido
	cuerpo->ApplyLinearImpulse(valor, punto_origen, true);

}

//M�todo de bucle principal, en �l ocurre todo el manejo de la l�gica
void Simulacion::iniciarSimulacion() {

	//Mientras la ventana est� abierta...
	while (ventana->isOpen()) {

		//Llama a actualizar las f�sicas
		actualizarFisicas(10,8);

		//Ejecuta la gesti�n de eventos
		gestionarEventos();

		//Ejecuta la actualizaci�n del renderizado en la ventana
		actualizarRenderizado();

		//DEBUG
		//depurarPosicionCuerpos();

	}

}

//M�todo que genera una ventana con las dimensiones y nombre especificadas y luego la retorna para ser almacenada y usada
RenderWindow* Simulacion::crearVentana(int altura, int anchura, string nombre) {

	//Retorna una nueva ventana con los par�metros recibidos
	return new RenderWindow(VideoMode(anchura, altura), nombre);

}

//M�todo que recibe inserciones para dibujarlas en la pantalla, limpia y actualiza el contenido de la misma
void Simulacion::actualizarRenderizado() {

	//Limpia la pantalla
	ventana->clear();

	//Carga los objetos a dibujar
	dibujarRectangulo(visual_suelo);
	dibujarCirculo(visual_bola);

	for (int i = 0; i < 2; i++) {

		dibujarRectangulo(visual_pared[i]);

	}

	//Muestra el contenido cargado
	ventana->display();

}

//M�todo encargado de procesar todos los inputs eventos del jugador sobre la ventana.
void Simulacion::gestionarEventos() {

	while (ventana->pollEvent(*gestor_eventos)) {

		switch (gestor_eventos->type) {

			//Evento: Cerrar ventana
		case Event::Closed:

			ventana->close();

			break;

		}

	}

}

//M�todo que actualiza la simulaci�n fisica usando las iteraciones suministradas por par�metro
void Simulacion::actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion) {

	//Almacena el tiempo
	float tiempo = 1.0f / 60.0f;

	//Hace que el mundo f�sico avance, actualizado los objetos contenidos en �l
	mundo->Step(tiempo, iteraciones_velocidad, iteraciones_posicion);

	//Tras actualizar las fisicas llama a la sincronizaci�n de visuales
	sincronizarObjetos();

}

//Este m�todo fija la gravedad y crea el mundo, adicionalmente genera los cuerpos usados para la simulaci�n
void Simulacion::crearFisicas() {

	//Establece el valor de la gravedad de la simulaci�n
	gravedad = { 0, 0.02 };

	//Crea el mundo suministrando la gravedad
	mundo = new b2World(gravedad);
	
	/////////////////////////////////////////////////////////////////////

	//DATOS DEL SUELO

	//Figura
	figura_suelo.SetAsBox(dimensiones_suelo.x, dimensiones_suelo.y);

	//Definici�n del Cuerpo
	definicion_suelo.type = b2_staticBody;
	definicion_suelo.position = { 16.0, 8.0 };

	//Creaci�n del Cuerpo
	cuerpo_suelo = mundo->CreateBody(&definicion_suelo);

	//Definici�n del Fijador
	definicion_fijador_suelo.shape = &figura_suelo;

	//Se le asigna el fixture al cuerpo del suelo
	fijador_suelo = cuerpo_suelo->CreateFixture(&definicion_fijador_suelo);

	/////////////////////////////////////////////////////////////////////

	//DATOS DE LAS PAREDES

	//Figura
	for (int i = 0; i < 2; i++) {

		figura_pared[i].SetAsBox(dimensiones_pared.x, dimensiones_pared.y);

	}

	//Definici�n del Cuerpo
	definicion_pared[0].type = b2_staticBody;
	definicion_pared[1].type = b2_staticBody;
	definicion_pared[0].position = { 2.0f, 10.0f };
	definicion_pared[1].position = { 16.0f, 10.0f };

	//Creaci�n del Cuerpo
	cuerpo_pared[0] = mundo->CreateBody(&definicion_pared[0]);
	cuerpo_pared[1] = mundo->CreateBody(&definicion_pared[1]);

	//Definici�n del Fijador
	definicion_fijador_pared[0].shape = &figura_pared[0];
	definicion_fijador_pared[1].shape = &figura_pared[1];

	//Se le asigna el fixture al cuerpo del suelo
	fijador_pared[0] = cuerpo_pared[0]->CreateFixture(&definicion_fijador_pared[0]);
	fijador_pared[1] = cuerpo_pared [1] ->CreateFixture(&definicion_fijador_pared[1]);

	/////////////////////////////////////////////////////////////////////

	//DATOS DE LA BOLA

	//Figura
	figura_bola.m_radius = radio_bola;

	//Definici�n de la Bola
	definicion_bola.type = b2_dynamicBody;
	definicion_bola.position = { 8.0f, -3.0f };
	definicion_bola.gravityScale = 5.0f;

	//Creaci�n de la Bola
	cuerpo_bola = mundo->CreateBody(&definicion_bola);

	//Definici�n del Fijador de la Bola
	definicion_fijador_bola.shape = &figura_bola;
	definicion_fijador_bola.restitution = 0.8f;
	definicion_fijador_bola.density = 0.4f;

	//Se le asigna el Fijador al cuerpo de la bola
	fijador_bola = cuerpo_bola->CreateFixture(&definicion_fijador_bola);
	
}

//M�todo encargado de generar una contraparte gr�fica para poder visualizar los cuerpos f�sicos. El metodo crea y posiciona
//las formas vinculadas a cada cuerpo, multiplicando las posiciones en metros por el valor de "metro a pixel"
void Simulacion::crearVisuales() {

	//Se crean vectores que guardar�n el tama�o para los objetos visuales, obtenidos al duplicar el tama�o de los f�sicos
	// y multiplicando el resultado por el valor de "pixeles por metro"
	Vector2f tamanio_final_suelo = { (dimensiones_suelo.x * 2) * PIXELES_POR_METRO, (dimensiones_suelo.y * 2) * PIXELES_POR_METRO };
	Vector2f tamanio_final_pared = { (dimensiones_pared.x * 2) * PIXELES_POR_METRO, (dimensiones_pared.y * 2) * PIXELES_POR_METRO };

	//Se asignan los tama�os y radios obtenidos a las figuras visuales
	visual_suelo.setSize(tamanio_final_suelo);
	for (int i = 0; i < 2; i++) {

		visual_pared[i].setSize(tamanio_final_pared);

	}
	visual_bola.setRadius(radio_bola * PIXELES_POR_METRO);

	//Se calcula la nueva posici�n, basandonos en la posici�n actual de sus contrapartes f�sicas
	Vector2f posicion_suelo = { cuerpo_suelo->GetPosition().x * PIXELES_POR_METRO, cuerpo_suelo->GetPosition().y * PIXELES_POR_METRO };
	Vector2f posicion_bola = { cuerpo_bola->GetPosition().x * PIXELES_POR_METRO, cuerpo_bola->GetPosition().y * PIXELES_POR_METRO };
	Vector2f posicion_pared[2];
	posicion_pared[0] = { cuerpo_pared[0]->GetPosition().x * PIXELES_POR_METRO, cuerpo_pared[0]->GetPosition().y * PIXELES_POR_METRO};
	posicion_pared[1] = { cuerpo_pared[1]->GetPosition().x * PIXELES_POR_METRO, cuerpo_pared[1]->GetPosition().y * PIXELES_POR_METRO };

	//Se asignan las posiciones obtenidas
	visual_suelo.setPosition(posicion_suelo);
	visual_bola.setPosition(posicion_bola);
	for (int i = 0; i < 2; i++) {

		visual_pared[i].setPosition(posicion_pared[i]);

	}

	//Se modifica el punto de origen para estar en el centro
	visual_suelo.setOrigin(tamanio_final_suelo.x / 2, tamanio_final_suelo.y / 2);
	for (int i = 0; i < 2; i++) {

		visual_pared[i].setOrigin(tamanio_final_pared.x / 2, tamanio_final_pared.y / 2);

	}
	visual_bola.setOrigin((radio_bola * PIXELES_POR_METRO), (radio_bola * PIXELES_POR_METRO));

	//Se modifica el color de cada figura para diferenciarlas
	visual_suelo.setFillColor(Color::Blue);
	visual_bola.setFillColor(Color::White);
	visual_pared[0].setFillColor(Color::Cyan);
	visual_pared[1].setFillColor(Color::Cyan);

}

//M�todo que permite cambiar la posici�n de un objeto en su parte f�sica y actualiza su visual para encajar con la antes mencionada
void Simulacion::reposicionarObjeto(b2Body* cuerpo, b2Vec2 posicion_nueva) {

	//Aplica la nueva transformaci�n (En este caso solamente posici�n, y no rotaci�n)
	cuerpo->SetTransform(posicion_nueva ,0);

	//Llama a la sincronizaci�n entre f�sicos y visuales
	sincronizarObjetos();

}

//M�todo simple que dibuja una figura rectangular pasada por par�metro. Usa la ventana nativa de la clase
void Simulacion::dibujarRectangulo(RectangleShape figura) {

	//Pasa el contenido suministrado a la ventana del programa para ser renderizado
	ventana->draw(figura);

}

//Variante del m�todo base de dibujar que en su lugar recibe una figura Circular
void Simulacion::dibujarCirculo(CircleShape figura) {

	//Pasa el contenido suministrado a la ventana del programa para ser renderizado
	ventana->draw(figura);

}

//Encargado de actualizar la posici�n de los objetos visuales para encajar con la de sus contrapartes f�sicas
void Simulacion::sincronizarObjetos() {

	//Obtiene la posici�n y la convierte a medida por pixel, usada para gr�ficos
	Vector2f posicion_suelo = { cuerpo_suelo->GetPosition().x * PIXELES_POR_METRO, cuerpo_suelo->GetPosition().y * PIXELES_POR_METRO };
	Vector2f posicion_bola = { cuerpo_bola->GetPosition().x * PIXELES_POR_METRO, cuerpo_bola->GetPosition().y * PIXELES_POR_METRO };
	Vector2f posicion_pared[2];

	for (int i = 0; i < 2; i++) {

		posicion_pared[i] = { cuerpo_pared[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_pared[i]->GetPosition().y * PIXELES_POR_METRO };

	}

	//Asigna las nuevas posiciones a cada cuerpo visual
	visual_suelo.setPosition(posicion_suelo);
	visual_bola.setPosition(posicion_bola);
	for (int i = 0; i < 2; i++) {

		visual_pared[i].setPosition(posicion_pared[i]);

	}

}

//M�todo DEBUG: Usado para mostrar en consola la posici�n de los cuerpos de la pantalla, tanto para la variante f�sica como la visual
void Simulacion::depurarPosicionCuerpos() {

	//Env�a la posici�n f�sica y visual del suelo a consola
	cout << "Posicion Suelo Fisico: " << cuerpo_suelo->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_suelo->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Suelo Visual: " << visual_suelo.getPosition().x << ", " << visual_suelo.getPosition().y << endl;

	//Env�a la posici�n f�sica y visual de la bola a consola
	cout << "Posicion Bola Fisica: " << cuerpo_bola->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_bola->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Bola Visual: " << visual_bola.getPosition().x << ", " << visual_bola.getPosition().y << endl;

	//Env�a la posici�n f�sica y visual de las paredes usando un bucle for
	for (int i = 0; i < 2; i++) {

		cout << "Posicion Pared Fisica " << i << ": " << cuerpo_pared[i]->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_pared[i]->GetPosition().y * PIXELES_POR_METRO << endl;
		cout << "Posicion Pared Visual " << i << ": " << visual_pared[i].getPosition().x << ", " << visual_pared[i].getPosition().y << endl;

	}
	
}