#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <box2d.h>
#include <iostream>
#include <cstdlib>

using namespace std;
using namespace sf;

class Simulacion {

private:

	//Constante que define a cuantos pixeles equivale un metro
	const int PIXELES_POR_METRO = 50;

	//Variables de la ventana del programa
	Vector2i dimensiones_ventana;
	string nombre_ventana;

	//Ventana
	RenderWindow* ventana;

	//Objeto de Eventos
	Event* gestor_eventos;

	//Variables de figuras dibujables
	b2Vec2 dimensiones_suelo;
	b2Vec2 dimensiones_pared;
	float radio_bola;

	//Figuras dibujables
	RectangleShape visual_suelo;
	RectangleShape visual_pared[2];
	CircleShape visual_bola;

	//////////////////////
	//Variables de Box2D//
	//////////////////////

	//Gravedad y mundo
	b2Vec2 gravedad;
	b2World* mundo;

	//Figura, Definici�n de Cuerpo y Cuerpo del objeto "Suelo"
	b2PolygonShape figura_suelo;
	b2BodyDef definicion_suelo;
	b2Body* cuerpo_suelo;

	//Definici�n del Fijador y Fijador del objeto "Suelo"
	b2FixtureDef definicion_fijador_suelo;
	b2Fixture* fijador_suelo;

	//Figura, Definici�n de Cuerpo y Cuerpo de los objetos "Paredes"
	b2PolygonShape figura_pared[2];
	b2BodyDef definicion_pared[2];
	b2Body* cuerpo_pared[2];

	//Definici�n del Fijador y Fijador del objetos "Paredes"
	b2FixtureDef definicion_fijador_pared[2];
	b2Fixture* fijador_pared[2];

	//Figura, Definici�n de Cuerpo y Cuerpo del objeto "Bola"
	b2CircleShape figura_bola;
	b2BodyDef definicion_bola;
	b2Body* cuerpo_bola;

	//Definici�n del Fijador y Fijador del objeto "Bola"
	b2FixtureDef definicion_fijador_bola;
	b2Fixture* fijador_bola;


public:

	//Constructor
	Simulacion(Vector2i dimensiones_programa, string nombre_programa);

	//M�todos sin retorno
	void iniciarSimulacion();
	void actualizarRenderizado();
	void gestionarEventos();
	void crearFisicas();
	void crearVisuales();
	void dibujarRectangulo(RectangleShape figura);
	void dibujarCirculo(CircleShape figura);
	void actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion);
	void sincronizarObjetos();
	void reposicionarObjeto(b2Body* cuerpo, b2Vec2 posicion_nueva);
	void aplicarFuerza(b2Body* cuerpo, b2Vec2 valor, b2Vec2 punto_origen);

	//M�todos con retorno de datos
	RenderWindow* crearVentana(int altura, int anchura, string nombre);

	//M�todos de depuraci�n
	void depurarPosicionCuerpos();

};

