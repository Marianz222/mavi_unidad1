#include "Simulacion.h"

//Constructor: Acepta como par�metros la dimension y el nombre de la ventana para el programa. Inicializa las variables y
//llama a m�todos de inicializaci�n
Simulacion::Simulacion(Vector2i dimensiones_programa, string nombre_programa) {

	//Iguala la variable de vector de dimension
	dimensiones_ventana = dimensiones_programa;

	//Iguala la variable de nombre
	nombre_ventana = nombre_programa;

	//Asigna una nueva ventana a la variable existente
	ventana = crearVentana(dimensiones_ventana.x, dimensiones_ventana.y, nombre_ventana);

	//Instancia el gestor de eventos
	gestor_eventos = new Event;

	//Fija las dimensiones de los cuerpos a crear
	dimensiones_suelo = {17.0f, 1.0f};
	dimensiones_pared = { 1.0f, 9.0f };
	dimensiones_obstaculo[0] = {1.0f, 1.0f};
	dimensiones_obstaculo[1] = {0.5f, 2.0f};

	//Radio en metros de la bola
	radio_bola = 1;

	//Llama a la creaci�n de la parte f�sica de los cuerpos
	crearFisicas();

	//Llama a la creaci�n de la parte visual de los cuerpos
	crearVisuales();

	//coloca los objetos en las posiciones deseadas
	reposicionarObjeto(cuerpo_suelo[0], {19.0f, 18.0f});
	reposicionarObjeto(cuerpo_suelo[1], {19.0f, 2.0f});
	reposicionarObjeto(cuerpo_bola, {20.0f, 8.0f});
	reposicionarObjeto(cuerpo_pared[0], {1.0f, 10.0f});
	reposicionarObjeto(cuerpo_pared[1], {37.0f, 10.0f});
	reposicionarObjeto(cuerpo_obstaculo[0], {8.0f, 8.0f});
	reposicionarObjeto(cuerpo_obstaculo[1], {24.0f, 12.0f});

	aplicarFuerza(cuerpo_bola, { 500.0f, 500.0f });

}

//M�todo que permite aplicar una fuerza lineal al cuerpo suministrado por par�metro, usando el valor
void Simulacion::aplicarFuerza(b2Body* cuerpo, b2Vec2 valor) {

	//Se aplica el impulso lineal (valor) al cuerpo en el punto de origen elegido, despertandolo si est� dormido
	cuerpo->ApplyForceToCenter(valor, true);

}

//M�todo de bucle principal, en �l ocurre todo el manejo de la l�gica
void Simulacion::iniciarSimulacion() {

	//Mientras la ventana est� abierta...
	while (ventana->isOpen()) {

		//Llama a actualizar las f�sicas
		actualizarFisicas(10,8);

		//Ejecuta la gesti�n de eventos
		gestionarEventos();

		//Ejecuta la actualizaci�n del renderizado en la ventana
		actualizarRenderizado();

		//DEBUG
		//depurarPosicionCuerpos();

	}

}

//M�todo que genera una ventana con las dimensiones y nombre especificadas y luego la retorna para ser almacenada y usada
RenderWindow* Simulacion::crearVentana(int altura, int anchura, string nombre) {

	//Retorna una nueva ventana con los par�metros recibidos
	return new RenderWindow(VideoMode(anchura, altura), nombre);

}

//M�todo que recibe inserciones para dibujarlas en la pantalla, limpia y actualiza el contenido de la misma
void Simulacion::actualizarRenderizado() {

	//Limpia la pantalla
	ventana->clear();

	//Carga los objetos a dibujar
	dibujarCirculo(visual_bola);

	//Bucle para cargar objetos iterando sobre arreglos de capacidad '2'
	for (int i = 0; i < 2; i++) {

		dibujarRectangulo(visual_suelo[i]);
		dibujarRectangulo(visual_pared[i]);
		dibujarRectangulo(visual_obstaculo[i]);

	}

	//Muestra el contenido cargado
	ventana->display();

}

//M�todo encargado de procesar todos los inputs eventos del jugador sobre la ventana.
void Simulacion::gestionarEventos() {

	while (ventana->pollEvent(*gestor_eventos)) {

		switch (gestor_eventos->type) {

			//Evento: Cerrar ventana
		case Event::Closed:

			ventana->close();

			break;

			//Evento: Tecla Presionada
		case Event::KeyPressed:

			switch (gestor_eventos->key.code) {

				//Tecla: Espacio
			case Keyboard::Space:

				//Aplica fuerza hacia arriba
				aplicarFuerza(cuerpo_bola, {0.0f, 100.0f});

				break;

				//Tecla: W
			case Keyboard::W:

				//Aplica fuerza hacia arriba
				aplicarFuerza(cuerpo_bola, { 0.0f, 100.0f });

				break;

				//Tecla: S
			case Keyboard::S:

				//Aplica fuerza hacia abajo
				aplicarFuerza(cuerpo_bola, { 0.0f, -100.0f });

				break;

				//Tecla: D
			case Keyboard::D:

				//Aplica fuerza hacia la derecha
				aplicarFuerza(cuerpo_bola, { 100.0f, 0.0f });

				break;

				//Tecla: A
			case Keyboard::A:

				//Aplica fuerza hacia la izquierda
				aplicarFuerza(cuerpo_bola, { -100.0f, 50.0f });

				break;

				
			}

		}

	}

}

//M�todo que actualiza la simulaci�n fisica usando las iteraciones suministradas por par�metro
void Simulacion::actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion) {

	//Almacena el tiempo
	float tiempo = 1.0f / 60.0f;

	//Hace que el mundo f�sico avance, actualizado los objetos contenidos en �l
	mundo->Step(tiempo, iteraciones_velocidad, iteraciones_posicion);

	//Tras actualizar las fisicas llama a la sincronizaci�n de visuales
	sincronizarObjetos();

}

//Este m�todo fija la gravedad y crea el mundo, adicionalmente genera los cuerpos usados para la simulaci�n
void Simulacion::crearFisicas() {

	//Establece el valor de la gravedad de la simulaci�n
	gravedad = { 0, 0.02 };

	//Crea el mundo suministrando la gravedad
	mundo = new b2World(gravedad);
	
	/////////////////////////////////////////////////////////////////////

	//DATOS DEL SUELO Y TECHO

	crearSuelosFisicos();

	/////////////////////////////////////////////////////////////////////

	//DATOS DE LAS PAREDES

	crearParedesFisicas();

	/////////////////////////////////////////////////////////////////////

	//DATOS DE LA BOLA

	//Llamada a crear bola fisica
	crearBolaFisica();
	
	/////////////////////////////////////////////////////////////////////

	//DATOS DEL SUELO Y TECHO

	//Llamada a crear obstaculos fisicos
	crearObstaculosFisicos();

}

//M�todo interno que crea los suelos f�sicos, utilizado desde "crearFisicas"
void Simulacion::crearSuelosFisicos() {

	//Figura
	for (int i = 0; i < 2; i++) {

		figura_suelo[i].SetAsBox(dimensiones_suelo.x, dimensiones_suelo.y);

	}

	//Definici�n del Cuerpo
	for (int i = 0; i < 2; i++) {

		definicion_suelo[i].type = b2_staticBody;

	}
	definicion_suelo[0].position = { 16.0, 8.0 };
	definicion_suelo[1].position = { 18.0, 8.0 };

	//Creaci�n del Cuerpo
	for (int i = 0; i < 2; i++) {

		cuerpo_suelo[i] = mundo->CreateBody(&definicion_suelo[i]);

	}

	//Definici�n del Fijador
	for (int i = 0; i < 2; i++) {

		definicion_fijador_suelo[i].shape = &figura_suelo[i];
		definicion_fijador_suelo[i].restitution = 0.9f;

	}

	//Se le asigna el fixture al cuerpo del suelo
	for (int i = 0; i < 2; i++) {

		fijador_suelo[i] = cuerpo_suelo[i]->CreateFixture(&definicion_fijador_suelo[i]);

	}

}

//M�todo interno que crea las paredes f�sicas al ser llamado, utilizado desde "crearFisicas"
void Simulacion::crearParedesFisicas() {

	//Figura
	for (int i = 0; i < 2; i++) {

		figura_pared[i].SetAsBox(dimensiones_pared.x, dimensiones_pared.y);

	}

	//Definici�n del Cuerpo
	definicion_pared[0].type = b2_staticBody;
	definicion_pared[1].type = b2_staticBody;
	definicion_pared[0].position = { 2.0f, 10.0f };
	definicion_pared[1].position = { 16.0f, 10.0f };

	//Creaci�n del Cuerpo
	cuerpo_pared[0] = mundo->CreateBody(&definicion_pared[0]);
	cuerpo_pared[1] = mundo->CreateBody(&definicion_pared[1]);

	//Definici�n del Fijador
	definicion_fijador_pared[0].shape = &figura_pared[0];
	definicion_fijador_pared[1].shape = &figura_pared[1];

	//Se le asigna el fixture al cuerpo del suelo
	fijador_pared[0] = cuerpo_pared[0]->CreateFixture(&definicion_fijador_pared[0]);
	fijador_pared[1] = cuerpo_pared[1]->CreateFixture(&definicion_fijador_pared[1]);

}

//M�todo interno que crea la bola f�sica al ser llamado, utilizado desde "crearFisicas"
void Simulacion::crearBolaFisica() {

	//Figura
	figura_bola.m_radius = radio_bola;

	//Definici�n de la Bola
	definicion_bola.type = b2_dynamicBody;
	definicion_bola.position = { 8.0f, -3.0f };
	definicion_bola.gravityScale = 5.0f;

	//Creaci�n de la Bola
	cuerpo_bola = mundo->CreateBody(&definicion_bola);

	//Definici�n del Fijador de la Bola
	definicion_fijador_bola.shape = &figura_bola;
	definicion_fijador_bola.restitution = 0.9f;
	definicion_fijador_bola.density = 0.4f;

	//Se le asigna el Fijador al cuerpo de la bola
	fijador_bola = cuerpo_bola->CreateFixture(&definicion_fijador_bola);

}

//M�todo interno que crea la bola f�sica al ser llamado, utilizado desde "crearFisicas"
void Simulacion::crearObstaculosFisicos() {

	//Figura
	for (int i = 0; i < 2; i++) {

		figura_obstaculo[i].SetAsBox(dimensiones_obstaculo[i].x, dimensiones_obstaculo[i].y);

	}

	//Definici�n del Cuerpo
	for (int i = 0; i < 2; i++) {

		definicion_obstaculo[i].type = b2_staticBody;

	}
	definicion_obstaculo[0].position = { 8.0f, 8.0f };
	definicion_obstaculo[1].position = { 12.0f, 18.0f };

	//Creaci�n del Cuerpo
	for (int i = 0; i < 2; i++) {

		cuerpo_obstaculo[i] = mundo->CreateBody(&definicion_obstaculo[i]);

	}

	//Definici�n del Fijador
	for (int i = 0; i < 2; i++) {

		definicion_fijador_obstaculo[i].shape = &figura_obstaculo[i];
		definicion_fijador_obstaculo[i].restitution = 0.8f;

	}

	//Se le asigna el fixture al cuerpo del suelo
	for (int i = 0; i < 2; i++) {

		fijador_obstaculo[i] = cuerpo_obstaculo[i]->CreateFixture(&definicion_fijador_obstaculo[i]);

	}

}

//M�todo encargado de generar una contraparte gr�fica para poder visualizar los cuerpos f�sicos. El metodo crea y posiciona
//las formas vinculadas a cada cuerpo, multiplicando las posiciones en metros por el valor de "metro a pixel"
void Simulacion::crearVisuales() {

	//Se crean vectores que guardar�n el tama�o para los objetos visuales, obtenidos al duplicar el tama�o de los f�sicos
	// y multiplicando el resultado por el valor de "pixeles por metro"
	Vector2f tamanio_final_suelo = { (dimensiones_suelo.x * 2) * PIXELES_POR_METRO, (dimensiones_suelo.y * 2) * PIXELES_POR_METRO };
	Vector2f tamanio_final_pared = { (dimensiones_pared.x * 2) * PIXELES_POR_METRO, (dimensiones_pared.y * 2) * PIXELES_POR_METRO };

	Vector2f tamanio_final_obstaculos[2];
	for (int i = 0; i < 2; i++) {

		tamanio_final_obstaculos[i] = { (dimensiones_obstaculo[i].x * 2) * PIXELES_POR_METRO, (dimensiones_obstaculo[i].y * 2) * PIXELES_POR_METRO };

	}

	//Se asignan los tama�os y radios obtenidos a las figuras visuales
	for (int i = 0; i < 2; i++) {

		visual_suelo[i].setSize(tamanio_final_suelo);
		visual_pared[i].setSize(tamanio_final_pared);
		visual_obstaculo[i].setSize(tamanio_final_obstaculos[i]);

	}
	visual_bola.setRadius(radio_bola * PIXELES_POR_METRO);

	//Se calcula la nueva posici�n, basandonos en la posici�n actual de sus contrapartes f�sicas
	Vector2f posicion_bola = { cuerpo_bola->GetPosition().x * PIXELES_POR_METRO, cuerpo_bola->GetPosition().y * PIXELES_POR_METRO };

	//Arreglos de vector para las posiciones
	Vector2f posicion_suelo[2];
	Vector2f posicion_pared[2];
	Vector2f posicion_obstaculo[2];

	//Bucle que itera 2 veces sobre cada arreglo fijando sus posiciones
	for (int i = 0; i < 2; i++) {

		posicion_suelo[i] = { cuerpo_suelo[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_suelo[i]->GetPosition().y * PIXELES_POR_METRO };
		posicion_pared[i] = { cuerpo_pared[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_pared[i]->GetPosition().y * PIXELES_POR_METRO };
		posicion_obstaculo[i] = { cuerpo_obstaculo[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_obstaculo[i]->GetPosition().y * PIXELES_POR_METRO };

	}

	//Se asignan las posiciones obtenidas
	visual_bola.setPosition(posicion_bola);
	for (int i = 0; i < 2; i++) {

		visual_suelo[i].setPosition(posicion_suelo[i]);
		visual_pared[i].setPosition(posicion_pared[i]);
		visual_obstaculo[i].setPosition(posicion_obstaculo[i]);

	}

	//Se modifica el punto de origen para estar en el centro
	for (int i = 0; i < 2; i++) {

		visual_suelo[i].setOrigin(tamanio_final_suelo.x / 2, tamanio_final_suelo.y / 2);
		visual_pared[i].setOrigin(tamanio_final_pared.x / 2, tamanio_final_pared.y / 2);
		visual_obstaculo[i].setOrigin(tamanio_final_obstaculos[i].x / 2, tamanio_final_obstaculos[i].y / 2);

	}
	visual_bola.setOrigin((radio_bola * PIXELES_POR_METRO), (radio_bola * PIXELES_POR_METRO));

	//Se modifica el color de cada figura para diferenciarlas
	visual_suelo[0].setFillColor(Color::Blue);
	visual_suelo[1].setFillColor(Color::Green);
	visual_bola.setFillColor(Color::White);
	visual_pared[0].setFillColor(Color::Cyan);
	visual_pared[1].setFillColor(Color::Cyan);
	visual_obstaculo[0].setFillColor(Color::Yellow);
	visual_obstaculo[1].setFillColor(Color::Magenta);

}

//M�todo que permite cambiar la posici�n de un objeto en su parte f�sica y actualiza su visual para encajar con la antes mencionada
void Simulacion::reposicionarObjeto(b2Body* cuerpo, b2Vec2 posicion_nueva) {

	//Aplica la nueva transformaci�n (En este caso solamente posici�n, y no rotaci�n)
	cuerpo->SetTransform(posicion_nueva ,0);

	//Llama a la sincronizaci�n entre f�sicos y visuales
	sincronizarObjetos();

}

//M�todo simple que dibuja una figura rectangular pasada por par�metro. Usa la ventana nativa de la clase
void Simulacion::dibujarRectangulo(RectangleShape figura) {

	//Pasa el contenido suministrado a la ventana del programa para ser renderizado
	ventana->draw(figura);

}

//Variante del m�todo base de dibujar que en su lugar recibe una figura Circular
void Simulacion::dibujarCirculo(CircleShape figura) {

	//Pasa el contenido suministrado a la ventana del programa para ser renderizado
	ventana->draw(figura);

}

//Encargado de actualizar la posici�n de los objetos visuales para encajar con la de sus contrapartes f�sicas
void Simulacion::sincronizarObjetos() {

	//Obtiene la posici�n y la convierte a medida por pixel, usada para gr�ficos
	Vector2f posicion_suelo[2];
	Vector2f posicion_bola = { cuerpo_bola->GetPosition().x * PIXELES_POR_METRO, cuerpo_bola->GetPosition().y * PIXELES_POR_METRO };
	Vector2f posicion_pared[2];
	Vector2f posicion_obstaculo[2];

	for (int i = 0; i < 2; i++) {

		posicion_suelo[i] = { cuerpo_suelo[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_suelo[i]->GetPosition().y * PIXELES_POR_METRO };
		posicion_pared[i] = { cuerpo_pared[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_pared[i]->GetPosition().y * PIXELES_POR_METRO };
		posicion_obstaculo[i] = { cuerpo_obstaculo[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_obstaculo[i]->GetPosition().y * PIXELES_POR_METRO };

	}

	//Asigna las nuevas posiciones a cada cuerpo visual
	visual_bola.setPosition(posicion_bola);
	for (int i = 0; i < 2; i++) {

		visual_suelo[i].setPosition(posicion_suelo[i]);
		visual_pared[i].setPosition(posicion_pared[i]);
		visual_obstaculo[i].setPosition(posicion_obstaculo[i]);

	}

}

//M�todo DEBUG: Usado para mostrar en consola la posici�n de los cuerpos de la pantalla, tanto para la variante f�sica como la visual
void Simulacion::depurarPosicionCuerpos() {

	//Env�a la posici�n f�sica y visual de la bola a consola
	cout << "Posicion Bola Fisica: " << cuerpo_bola->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_bola->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Bola Visual: " << visual_bola.getPosition().x << ", " << visual_bola.getPosition().y << endl;

	//Env�a la posici�n f�sica y visual de las paredes, techo, suelo y obst�culos usando un bucle for de 2 iteraciones
	for (int i = 0; i < 2; i++) {

		cout << "Posicion Suelo Fisico " << i << "; " << cuerpo_suelo[i]->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_suelo[i]->GetPosition().y * PIXELES_POR_METRO << endl;
		cout << "Posicion Suelo Visual " << i << "; " << visual_suelo[i].getPosition().x << ", " << visual_suelo[i].getPosition().y << endl;

		cout << "Posicion Pared Fisica " << i << ": " << cuerpo_pared[i]->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_pared[i]->GetPosition().y * PIXELES_POR_METRO << endl;
		cout << "Posicion Pared Visual " << i << ": " << visual_pared[i].getPosition().x << ", " << visual_pared[i].getPosition().y << endl;

		cout << "Posicion Obstaculo Fisica " << i << ": " << cuerpo_obstaculo[i]->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_obstaculo[i]->GetPosition().y * PIXELES_POR_METRO << endl;
		cout << "Posicion Obstaculo Visual " << i << ": " << visual_obstaculo[i].getPosition().x << ", " << visual_obstaculo[i].getPosition().y << endl;

	}
	
}