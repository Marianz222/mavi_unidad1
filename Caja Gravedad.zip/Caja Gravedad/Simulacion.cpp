#include "Simulacion.h"

//Constructor: Acepta como par�metros la dimension y el nombre de la ventana para el programa. Inicializa las variables y
//llama a m�todos de inicializaci�n
Simulacion::Simulacion(Vector2i dimensiones_programa, string nombre_programa) {

	//Iguala la variable de vector de dimension
	dimensiones_ventana = dimensiones_programa;

	//Iguala la variable de nombre
	nombre_ventana = nombre_programa;

	//Asigna una nueva ventana a la variable existente
	ventana = crearVentana(dimensiones_ventana.x, dimensiones_ventana.y, nombre_ventana);

	//Instancia el gestor de eventos
	gestor_eventos = new Event;

	//Fija las dimensiones de los cuerpos a crear
	dimensiones_caja = {1.0f, 1.0f};
	dimensiones_suelo = {6.0f, 1.0f};

	//Llama a la creaci�n de la parte f�sica de los cuerpos
	crearFisicas();

	//Llama a la creaci�n de la parte visual de los cuerpos
	crearVisuales();

	//coloca los objetos en las posiciones deseadas
	reposicionarObjeto(cuerpo_caja, {20.0f, 4.0f});
	reposicionarObjeto(cuerpo_suelo, {20.0f, 18.0f});

}

//M�todo de bucle principal, en �l ocurre todo el manejo de la l�gica
void Simulacion::iniciarSimulacion() {

	//Mientras la ventana est� abierta...
	while (ventana->isOpen()) {

		//Llama a actualizar las f�sicas
		actualizarFisicas(10,8);

		//Ejecuta la gesti�n de eventos
		gestionarEventos();

		//Ejecuta la actualizaci�n del renderizado en la ventana
		actualizarRenderizado();

		//DEBUG
		//depurarPosicionCuerpos();

	}

}

//M�todo DEBUG: Usado para mostrar en consola la posici�n de los cuerpos de la pantalla, tanto para la variante f�sica como la visual
void Simulacion::depurarPosicionCuerpos() {

	//Env�a la posici�n f�sica y visual de la caja a consola
	cout << "Posicion Caja Fisica: " << cuerpo_caja->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_caja->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Caja Visual: " << visual_caja.getPosition().x << ", " << visual_caja.getPosition().y << endl;

	//Env�a la posici�n f�sica y visual del suelo a consola
	cout << "Posicion Suelo Fisico: " << cuerpo_suelo->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_suelo->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Suelo Visual: " << visual_suelo.getPosition().x << ", " << visual_suelo.getPosition().y << endl;

}

//M�todo que genera una ventana con las dimensiones y nombre especificadas y luego la retorna para ser almacenada y usada
RenderWindow* Simulacion::crearVentana(int altura, int anchura, string nombre) {

	//Retorna una nueva ventana con los par�metros recibidos
	return new RenderWindow(VideoMode(anchura, altura), nombre);

}

//M�todo que recibe inserciones para dibujarlas en la pantalla, limpia y actualiza el contenido de la misma
void Simulacion::actualizarRenderizado() {

	//Limpia la pantalla
	ventana->clear();

	//Carga los objetos a dibujar
	dibujarRectangulo(visual_caja);
	dibujarRectangulo(visual_suelo);

	//Muestra el contenido cargado
	ventana->display();

}

//M�todo encargado de procesar todos los inputs eventos del jugador sobre la ventana.
void Simulacion::gestionarEventos() {

	while (ventana->pollEvent(*gestor_eventos)) {

		switch (gestor_eventos->type) {

			//Evento: Cerrar ventana
		case Event::Closed:

			ventana->close();

			break;

		}

	}

}

//M�todo que actualiza la simulaci�n fisica usando las iteraciones suministradas por par�metro
void Simulacion::actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion) {

	//Almacena el tiempo
	float tiempo = 1.0f / 60.0f;

	//Hace que el mundo f�sico avance, actualizado los objetos contenidos en �l
	mundo->Step(tiempo, iteraciones_velocidad, iteraciones_posicion);

	//Tras actualizar las fisicas llama a la sincronizaci�n de visuales
	sincronizarObjetos();

}

//Este m�todo fija la gravedad y crea el mundo, adicionalmente genera los cuerpos usados para la simulaci�n
void Simulacion::crearFisicas() {

	//Establece el valor de la gravedad de la simulaci�n
	gravedad = { 0, 0.02 };

	//Crea el mundo suministrando la gravedad
	mundo = new b2World(gravedad);

	//DATOS DE LA CAJA

	//Figura
	figura_caja.SetAsBox(dimensiones_caja.x, dimensiones_caja.y);

	//Definicion del Cuerpo
	definicion_caja.type = b2_dynamicBody;
	definicion_caja.position = { 5.0, 5.0 };

	//Creaci�n del Cuerpo
	cuerpo_caja = mundo->CreateBody(&definicion_caja);
	
	//Definicion del Fijador
	definicion_fijador_caja.shape = &figura_caja;
	definicion_fijador_caja.density = 1.0f;
	definicion_fijador_caja.friction = 0.2f;

	//Se le asigna el fixture al cuerpo de la caja
	fijador_caja = cuerpo_caja->CreateFixture(&definicion_fijador_caja);
	
	/////////////////////////////////////////////////////////////////////

	//DATOS DEL SUELO

	//Figura
	figura_suelo.SetAsBox(dimensiones_suelo.x, dimensiones_suelo.y);

	//Definici�n del Cuerpo
	definicion_suelo.type = b2_staticBody;
	definicion_suelo.position = { 0.0, -5.0 };

	//Creaci�n del Cuerpo
	cuerpo_suelo = mundo->CreateBody(&definicion_suelo);

	//Definici�n del Fijador
	definicion_fijador_suelo.shape = &figura_suelo;

	//Se le asigna el fixture al cuerpo del suelo
	fijador_suelo = cuerpo_suelo->CreateFixture(&definicion_fijador_suelo);
	
}

//M�todo encargado de generar una contraparte gr�fica para poder visualizar los cuerpos f�sicos. El metodo crea y posiciona
//las formas vinculadas a cada cuerpo, multiplicando las posiciones en metros por el valor de "metro a pixel"
void Simulacion::crearVisuales() {

	//Los visuales se colocan inicialmente en el centro de la pantalla para que se originen en el mismo punto que los objetos f�sicos
	visual_caja.setPosition(dimensiones_ventana.x / 2, dimensiones_ventana.y / 2);
	visual_suelo.setPosition(dimensiones_ventana.x / 2, dimensiones_ventana.y / 2);

	//Se crean 2 vectores que guardar�n el tama�o para los objetos visuales, obtenidos al duplicar el tama�o de los f�sicos
	// y multiplicando el resultado por el valor de "pixeles por metro"
	Vector2f tamanio_final_caja = { (dimensiones_caja.x * 2) * PIXELES_POR_METRO, (dimensiones_caja.y * 2) * PIXELES_POR_METRO };
	Vector2f tamanio_final_suelo = { (dimensiones_suelo.x * 2) * PIXELES_POR_METRO, (dimensiones_suelo.y * 2) * PIXELES_POR_METRO };

	//Se asignan los tama�os obtenidos a las figuras visuales
	visual_caja.setSize(tamanio_final_caja);
	visual_suelo.setSize(tamanio_final_suelo);

	//Se calcula la nueva posici�n, basandonos en la posici�n actual de sus contrapartes f�sicas
	Vector2f posicion_caja = { cuerpo_caja->GetPosition().x * PIXELES_POR_METRO, cuerpo_caja->GetPosition().y * PIXELES_POR_METRO };
	Vector2f posicion_suelo = { cuerpo_suelo->GetPosition().x * PIXELES_POR_METRO, cuerpo_suelo->GetPosition().y * PIXELES_POR_METRO };

	//Se asignan las posiciones obtenidas
	visual_caja.setPosition(posicion_caja);
	visual_suelo.setPosition(posicion_suelo);

	//Se modifica el punto de origen para estar en el centro
	visual_caja.setOrigin(tamanio_final_caja.x / 2, tamanio_final_caja.y / 2);
	visual_suelo.setOrigin(tamanio_final_suelo.x / 2, tamanio_final_suelo.y / 2);

	//Se modifica el color de cada figura para diferenciarlas
	visual_caja.setFillColor(Color::Yellow);
	visual_suelo.setFillColor(Color::Blue);

}

//M�todo que permite cambiar la posici�n de un objeto en su parte f�sica y actualiza su visual para encajar con la antes mencionada
void Simulacion::reposicionarObjeto(b2Body* cuerpo, b2Vec2 posicion_nueva) {

	//Aplica la nueva transformaci�n (En este caso solamente posici�n, y no rotaci�n)
	cuerpo->SetTransform(posicion_nueva ,0);

	//Llama a la sincronizaci�n entre f�sicos y visuales
	sincronizarObjetos();

}

//M�todo simple que dibuja una figura rectangular pasada por par�metro. Usa la ventana nativa de la clase
void Simulacion::dibujarRectangulo(RectangleShape figura) {

	//Pasa el contenido suministrado a la ventana del programa para ser renderizado
	ventana->draw(figura);

}

//Encargado de actualizar la posici�n de los objetos visuales para encajar con la de sus contrapartes f�sicas
void Simulacion::sincronizarObjetos() {

	//Obtiene la posici�n y la convierte a medida por pixel, usada para gr�ficos
	Vector2f posicion_caja = { cuerpo_caja->GetPosition().x * PIXELES_POR_METRO, cuerpo_caja->GetPosition().y * PIXELES_POR_METRO };
	Vector2f posicion_suelo = { cuerpo_suelo->GetPosition().x * PIXELES_POR_METRO, cuerpo_suelo->GetPosition().y * PIXELES_POR_METRO };

	//Asigna las nuevas posiciones a cada cuerpo visual
	visual_caja.setPosition(posicion_caja);
	visual_suelo.setPosition(posicion_suelo);

}