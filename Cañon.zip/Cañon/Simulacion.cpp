#include "Simulacion.h"

//Constructor: Acepta como par�metros la dimension y el nombre de la ventana para el programa. Inicializa las variables y
//llama a m�todos de inicializaci�n
Simulacion::Simulacion(Vector2i dimensiones_programa, string nombre_programa) {

	//Iguala la variable de vector de dimension
	dimensiones_ventana = dimensiones_programa;

	//Iguala la variable de nombre
	nombre_ventana = nombre_programa;

	//Asigna una nueva ventana a la variable existente
	ventana = crearVentana(dimensiones_ventana.x, dimensiones_ventana.y, nombre_ventana);

	//Instancia el gestor de eventos
	gestor_eventos = new Event;

	//Fija las dimensiones de los cuerpos a crear
	dimensiones_suelo = {17.0f, 1.0f};
	dimensiones_pared = { 1.0f, 9.0f };
	
	dimensiones_rampa = { 0.5f, 4.0f};

	//dimensiones_arma_fondo = {0.5, 0.25}; //Tama�o del Fondo
	//dimensiones_arma_barril = { 0.25f, 1.0f }; //Tama�o de las Paredes o Barril
	
	//Radio en metros de la bola y la base del arma
	radio_bola = 0.49f;
	//radio_base_arma = 1;

	//Llama a la creaci�n de la parte f�sica de los cuerpos
	crearFisicas();

	//Llama a la creaci�n de la parte visual de los cuerpos
	crearVisuales();

	//coloca los objetos en las posiciones deseadas
	
	reposicionarObjeto(cuerpo_suelo[0], {19.0f, 18.0f});
	reposicionarObjeto(cuerpo_suelo[1], {19.0f, 2.0f});
	reposicionarObjeto(cuerpo_pared[0], {1.0f, 10.0f});
	reposicionarObjeto(cuerpo_pared[1], {37.0f, 10.0f});
	reposicionarObjeto(cuerpo_bola, { 4.0f, 14.5f });

	reposicionarObjeto(cuerpo_rampa, {6.0f, 16.0f});
	/*
	//Reposiciona los componentes del arma
	reposicionarObjeto(cuerpo_arma_base, {4.0f ,16.0f}); //Base
	reposicionarObjeto(cuerpo_arma_fondo, {4.0f, 14.75f}); //Fondo
	reposicionarObjeto(cuerpo_arma_barril_izq, {3.25f, 14.0f}); //Barril Izquierdo
	reposicionarObjeto(cuerpo_arma_barril_der, {4.75f, 14.0f}); //Barril Derecho */

}

//M�todo que permite aplicar una fuerza lineal al cuerpo suministrado por par�metro, usando el valor
void Simulacion::aplicarFuerza(b2Body* cuerpo, b2Vec2 valor) {

	//Se aplica el impulso lineal (valor) al cuerpo en el punto de origen elegido, despertandolo si est� dormido
	cuerpo->ApplyForceToCenter(valor, true);

}

//M�todo de bucle principal, en �l ocurre todo el manejo de la l�gica
void Simulacion::iniciarSimulacion() {

	//Mientras la ventana est� abierta...
	while (ventana->isOpen()) {

		//Llama a actualizar las f�sicas
		actualizarFisicas(10,8);

		//Ejecuta la gesti�n de eventos
		gestionarEventos();

		//Ejecuta la actualizaci�n del renderizado en la ventana
		actualizarRenderizado();

		//DEBUG
		//depurarPosicionCuerpos();

	}

}

//M�todo que genera una ventana con las dimensiones y nombre especificadas y luego la retorna para ser almacenada y usada
RenderWindow* Simulacion::crearVentana(int altura, int anchura, string nombre) {

	//Retorna una nueva ventana con los par�metros recibidos
	return new RenderWindow(VideoMode(anchura, altura), nombre);

}

//M�todo que recibe inserciones para dibujarlas en la pantalla, limpia y actualiza el contenido de la misma
void Simulacion::actualizarRenderizado() {

	//Limpia la pantalla
	ventana->clear();

	//Carga los objetos a dibujar
	dibujarCirculo(visual_bola);

	//Bucle para cargar objetos iterando sobre arreglos de capacidad '2'
	for (int i = 0; i < 2; i++) {

		dibujarRectangulo(visual_suelo[i]);
		dibujarRectangulo(visual_pared[i]);

	}

	dibujarRectangulo(visual_rampa);

	//Carga los objetos del arma para ser dibujados
	/*
	dibujarRectangulo(visual_arma_fondo);
	dibujarRectangulo(visual_arma_barril_izq);
	dibujarRectangulo(visual_arma_barril_der);
	dibujarCirculo(visual_arma_base);

	//Carga las lineas debug que representan las uniones de las juntas
	dibujarLinea({ junta_principal->GetAnchorA().x, junta_principal->GetAnchorA().y}, { junta_principal->GetAnchorB().x, junta_principal->GetAnchorB().y }, Color::White);
	dibujarLinea({ junta_izq->GetAnchorA().x, junta_izq->GetAnchorA().y }, { junta_izq->GetAnchorB().x, junta_izq->GetAnchorB().y }, Color::White);
	dibujarLinea({ junta_der->GetAnchorA().x, junta_der->GetAnchorA().y }, { junta_der->GetAnchorB().x, junta_der->GetAnchorB().y }, Color::White);
	*/

	//Muestra el contenido cargado
	ventana->display();

}

//M�todo encargado de procesar todos los inputs eventos del jugador sobre la ventana.
void Simulacion::gestionarEventos() {

	while (ventana->pollEvent(*gestor_eventos)) {

		switch (gestor_eventos->type) {

			//Evento: Cerrar ventana
		case Event::Closed:

			ventana->close();

			break;

			//Evento: Tecla Presionada
		case Event::KeyPressed:

			bool puede_rotar = true;

			switch (gestor_eventos->key.code) {

				//Tecla: Espacio - Dispara el proyectil
			case Keyboard::Space:

				//Si ya se ha disparado, no se puede continuar
				if (ha_disparado) { return; }

				//Aplica fuerza para disparar la bola con la direcci�n del ca��n
				aplicarFuerza(cuerpo_bola, { 100.0f, 15.0f });

				//Asigna el bool de disparo
				ha_disparado = true;

				break;

				//Tecla: Q - Rota el arma en direcci�n contra-reloj
			case Keyboard::Q:

			    puede_rotar = cuerpo_rampa->GetAngle() >= 0.1;

				if (!puede_rotar) { return; }

				//Llama a rotar el cuerpo
			    rotarCuerpo(cuerpo_rampa, -0.1f);

				break;

				//Tecla: E - Rota el arma en direcci�n del reloj
			case Keyboard::E:

				puede_rotar = cuerpo_rampa->GetAngle() <= 1.5;

				if (!puede_rotar) { return; }

				//Llama a rotar el cuerpo
				rotarCuerpo(cuerpo_rampa, 0.1f);

				break;

				//Tecla: R - Reinicia la simulaci�n, recolocando el proyectil en su origen, reiniciando la rotaci�n y la variable bool
			case Keyboard::R:

				//Registra por consola que el reinicio se efectu�
				cout << "[INFO]: Simulacion Reiniciada!" << endl;

				//Reinicia la variable de control bool, la rotaci�n de la base y la posici�n del proyectil
				ha_disparado = false;
				reposicionarObjeto(cuerpo_bola, { 4.0f, 14.3f });
				cuerpo_bola->SetLinearVelocity({0.0f, 0.0f});

				//Adicionalmente inhabilita que el proyectil pueda "dormir", para asi ser influenciado por la gravedad tras reiniciar
				cuerpo_bola->SetSleepingAllowed(false);
				
			}

		}

	}

}

//M�todo que rota un cuerpo sobre su propio eje, usando los radianes suministrados
void Simulacion::rotarCuerpo(b2Body* cuerpo, float radianes) {

	//Actualiza la rotaci�n
	cuerpo->SetTransform(cuerpo->GetPosition(), cuerpo->GetAngle() + radianes);

	//Tras actualizar las fisicas llama a la sincronizaci�n de visuales
	sincronizarObjetos();

}

//M�todo que actualiza la simulaci�n fisica usando las iteraciones suministradas por par�metro
void Simulacion::actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion) {

	//Almacena el tiempo
	float tiempo = 1.0f / 60.0f;

	//Hace que el mundo f�sico avance, actualizado los objetos contenidos en �l
	mundo->Step(tiempo, iteraciones_velocidad, iteraciones_posicion);

	//Tras actualizar las fisicas llama a la sincronizaci�n de visuales
	sincronizarObjetos();

}

//Este m�todo fija la gravedad y crea el mundo, adicionalmente genera los cuerpos usados para la simulaci�n
void Simulacion::crearFisicas() {

	//Establece el valor de la gravedad de la simulaci�n
	gravedad = { 0, 0.02 };

	//Crea el mundo suministrando la gravedad
	mundo = new b2World(gravedad);
	
	/////////////////////////////////////////////////////////////////////

	//DATOS DEL SUELO Y TECHO

	crearSuelosFisicos();

	/////////////////////////////////////////////////////////////////////

	//DATOS DE LAS PAREDES

	crearParedesFisicas();

	/////////////////////////////////////////////////////////////////////

	//DATOS DE LA BOLA

	//Llamada a crear bola fisica
	crearBolaFisica();

	/////////////////////////////////////////////////////////////////////

	//DATOS DE LA RAMPA

	//Llamada a crear la rampa
	crearRampaFisica();

	/////////////////////////////////////////////////////////////////////

	//DATOS DEL ARMA/CA��N

	//Llamada a crear el ca��n con todos sus componentes
	//crearArmaFisica();

	/////////////////////////////////////////////////////////////

	//Creaci�n de Juntas
	//crearJuntas();

}

//M�todo interno que crea los suelos f�sicos, utilizado desde "crearFisicas"
void Simulacion::crearRampaFisica() {

	//Figura
	figura_rampa.SetAsBox(dimensiones_rampa.x, dimensiones_rampa.y);

	//Definici�n del Cuerpo
	definicion_rampa.type = b2_staticBody;
	definicion_rampa.position = { 12.0f, 24.0f };

	//Creaci�n del cuerpo
	cuerpo_rampa = mundo->CreateBody(&definicion_rampa);

	//Definici�n del Fijador
	definicion_fijador_rampa.shape = &figura_rampa;
	definicion_fijador_rampa.friction = 0.8f;

	//Se le asigna el fixture al cuerpo del suelo
	fijador_rampa = cuerpo_rampa->CreateFixture(&definicion_fijador_rampa);

}

//M�todo interno que crea los suelos f�sicos, utilizado desde "crearFisicas"
void Simulacion::crearSuelosFisicos() {

	//Figura
	for (int i = 0; i < 2; i++) {

		figura_suelo[i].SetAsBox(dimensiones_suelo.x, dimensiones_suelo.y);

	}

	//Definici�n del Cuerpo
	for (int i = 0; i < 2; i++) {

		definicion_suelo[i].type = b2_staticBody;

	}
	definicion_suelo[0].position = { 16.0, 8.0 };
	definicion_suelo[1].position = { 18.0, 8.0 };

	//Creaci�n del Cuerpo
	for (int i = 0; i < 2; i++) {

		cuerpo_suelo[i] = mundo->CreateBody(&definicion_suelo[i]);

	}

	//Definici�n del Fijador
	for (int i = 0; i < 2; i++) {

		definicion_fijador_suelo[i].shape = &figura_suelo[i];
		definicion_fijador_suelo[i].restitution = 0.9f;

	}

	//Se le asigna el fixture al cuerpo del suelo
	for (int i = 0; i < 2; i++) {

		fijador_suelo[i] = cuerpo_suelo[i]->CreateFixture(&definicion_fijador_suelo[i]);

	}

}

//M�todo interno que crea las paredes f�sicas al ser llamado, utilizado desde "crearFisicas"
void Simulacion::crearParedesFisicas() {

	//Figura
	for (int i = 0; i < 2; i++) {

		figura_pared[i].SetAsBox(dimensiones_pared.x, dimensiones_pared.y);

	}

	//Definici�n del Cuerpo
	definicion_pared[0].type = b2_staticBody;
	definicion_pared[1].type = b2_staticBody;
	definicion_pared[0].position = { 2.0f, 10.0f };
	definicion_pared[1].position = { 16.0f, 10.0f };

	//Creaci�n del Cuerpo
	cuerpo_pared[0] = mundo->CreateBody(&definicion_pared[0]);
	cuerpo_pared[1] = mundo->CreateBody(&definicion_pared[1]);

	//Definici�n del Fijador
	definicion_fijador_pared[0].shape = &figura_pared[0];
	definicion_fijador_pared[1].shape = &figura_pared[1];

	//Se le asigna el fixture al cuerpo del suelo
	fijador_pared[0] = cuerpo_pared[0]->CreateFixture(&definicion_fijador_pared[0]);
	fijador_pared[1] = cuerpo_pared[1]->CreateFixture(&definicion_fijador_pared[1]);

}

//M�todo interno que crea la bola f�sica al ser llamado, utilizado desde "crearFisicas"
void Simulacion::crearBolaFisica() {

	//Figura
	figura_bola.m_radius = radio_bola;

	//Definici�n de la Bola
	definicion_bola.type = b2_dynamicBody;
	definicion_bola.position = { 8.0f, -3.0f };
	definicion_bola.gravityScale = 4.0f;

	//Creaci�n de la Bola
	cuerpo_bola = mundo->CreateBody(&definicion_bola);

	//Definici�n del Fijador de la Bola
	definicion_fijador_bola.shape = &figura_bola;
	definicion_fijador_bola.restitution = 0.1f;
	definicion_fijador_bola.density = 0.6f;

	//Se le asigna el Fijador al cuerpo de la bola
	fijador_bola = cuerpo_bola->CreateFixture(&definicion_fijador_bola);

}

//M�todo interno que crea los componentes y la base del arma/ca��n, utilizado desde "crearFisicas"
void Simulacion::crearArmaFisica() {
	/*
	//Figura
	figura_arma_fondo.SetAsBox(dimensiones_arma_fondo.x, dimensiones_arma_fondo.y);
	figura_arma_barril_izq.SetAsBox(dimensiones_arma_barril.x, dimensiones_arma_barril.y);
	figura_arma_barril_der.SetAsBox(dimensiones_arma_barril.x, dimensiones_arma_barril.y);
	figura_arma_base.m_radius = radio_base_arma;

	//Definici�n del Cuerpo
	definicion_arma_fondo.type = b2_kinematicBody;
	definicion_arma_barril_izq.type = b2_kinematicBody;
	definicion_arma_barril_der.type = b2_kinematicBody;
	definicion_arma_base.type = b2_staticBody;

	definicion_arma_fondo.position = { 4.75f, 14.25f };
	definicion_arma_barril_izq.position = { 3.25f, 14.25f };
	definicion_arma_barril_der.position = { 3.0f, 10.0f };
	definicion_arma_base.position = { 4.0f ,16.0f };

	//Creaci�n del Cuerpo
	cuerpo_arma_fondo = mundo->CreateBody(&definicion_arma_fondo);
	cuerpo_arma_barril_izq = mundo->CreateBody(&definicion_arma_barril_izq);
	cuerpo_arma_barril_der = mundo->CreateBody(&definicion_arma_barril_der);
	cuerpo_arma_base = mundo->CreateBody(&definicion_arma_base);

	//Definici�n del Fijador
	definicion_fijador_arma_fondo.shape = &figura_arma_fondo;
	definicion_fijador_arma_barril_izq.shape = &figura_arma_barril_izq;
	definicion_fijador_arma_barril_der.shape = &figura_arma_barril_der;
	definicion_fijador_arma_base.shape = &figura_arma_base;

	//Se le asigna el fixture a los cuerpos componentes del arma
	fijador_arma[0] = cuerpo_arma_fondo->CreateFixture(&definicion_fijador_arma_fondo);
	fijador_arma[1] = cuerpo_arma_barril_izq->CreateFixture(&definicion_fijador_arma_barril_izq);
	fijador_arma[2] = cuerpo_arma_barril_der->CreateFixture(&definicion_fijador_arma_barril_der);
	fijador_arma[3] = cuerpo_arma_base->CreateFixture(&definicion_fijador_arma_base);
	*/
}

void Simulacion::crearJuntas() {
	/*
	//Convertir las juntas en distance joints!!

	//Almacena el �ngulo maximo de rotaci�n y lo convierte a radianes para su uso
	float angulo_limite = 45.0f;
	float limite_rotacion = angulo_limite * (b2_pi / 180.0f);

	//Se asignan los cuerpos a conectar para todas las juntas
	definicion_junta_principal.bodyA = cuerpo_arma_base;
	definicion_junta_principal.bodyB = cuerpo_arma_fondo;

	definicion_junta_izq.bodyA = cuerpo_arma_base;
	definicion_junta_izq.bodyB = cuerpo_arma_barril_izq;

	definicion_junta_der.bodyA = cuerpo_arma_base;
	definicion_junta_der.bodyB = cuerpo_arma_barril_der;

	//Activa el l�mite y lo establece usando los radianes calculados anteriormente 
	definicion_junta_principal.enableLimit = true;
	definicion_junta_principal.upperAngle = limite_rotacion;
	definicion_junta_principal.lowerAngle = -limite_rotacion;

	definicion_junta_izq.enableLimit = true;
	definicion_junta_izq.upperAngle = limite_rotacion;
	definicion_junta_izq.lowerAngle = -limite_rotacion;

	definicion_junta_der.enableLimit = true;
	definicion_junta_der.upperAngle = limite_rotacion;
	definicion_junta_der.lowerAngle = -limite_rotacion;

	//Crea las nuevas juntas y las almacena en sus variables
	junta_principal = (b2RevoluteJoint*)mundo->CreateJoint(&definicion_junta_principal);
	junta_izq = (b2RevoluteJoint*)mundo->CreateJoint(&definicion_junta_izq);
	junta_der = (b2RevoluteJoint*)mundo->CreateJoint(&definicion_junta_der);
	*/
}

//M�todo encargado de generar una contraparte gr�fica para poder visualizar los cuerpos f�sicos. El metodo crea y posiciona
//las formas vinculadas a cada cuerpo, multiplicando las posiciones en metros por el valor de "metro a pixel"
void Simulacion::crearVisuales() {

	//Se crean vectores que guardar�n el tama�o para los objetos visuales, obtenidos al duplicar el tama�o de los f�sicos
	// y multiplicando el resultado por el valor de "pixeles por metro"
	Vector2f tamanio_final_suelo = { (dimensiones_suelo.x * 2) * PIXELES_POR_METRO, (dimensiones_suelo.y * 2) * PIXELES_POR_METRO };
	Vector2f tamanio_final_pared = { (dimensiones_pared.x * 2) * PIXELES_POR_METRO, (dimensiones_pared.y * 2) * PIXELES_POR_METRO };
	Vector2f tamanio_final_rampa = { (dimensiones_rampa.x * 2) * PIXELES_POR_METRO, (dimensiones_rampa.y * 2) * PIXELES_POR_METRO };

	//Se asignan los tama�os y radios obtenidos a las figuras visuales
	for (int i = 0; i < 2; i++) {

		visual_suelo[i].setSize(tamanio_final_suelo);
		visual_pared[i].setSize(tamanio_final_pared);

	}
	visual_bola.setRadius(radio_bola * PIXELES_POR_METRO);
	visual_rampa.setSize(tamanio_final_rampa);

	//Se calcula la nueva posici�n, basandonos en la posici�n actual de sus contrapartes f�sicas
	Vector2f posicion_bola = { cuerpo_bola->GetPosition().x * PIXELES_POR_METRO, cuerpo_bola->GetPosition().y * PIXELES_POR_METRO };
	Vector2f posicion_rampa = { cuerpo_rampa->GetPosition().x * PIXELES_POR_METRO, cuerpo_rampa->GetPosition().y * PIXELES_POR_METRO };

	//Arreglos de vector para las posiciones
	Vector2f posicion_suelo[2];
	Vector2f posicion_pared[2];

	//Bucle que itera 2 veces sobre cada arreglo fijando sus posiciones
	for (int i = 0; i < 2; i++) {

		posicion_suelo[i] = { cuerpo_suelo[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_suelo[i]->GetPosition().y * PIXELES_POR_METRO };
		posicion_pared[i] = { cuerpo_pared[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_pared[i]->GetPosition().y * PIXELES_POR_METRO };

	}

	//Se asignan las posiciones obtenidas para la bola, el suelo y las paredes
	visual_bola.setPosition(posicion_bola);
	for (int i = 0; i < 2; i++) {

		visual_suelo[i].setPosition(posicion_suelo[i]);
		visual_pared[i].setPosition(posicion_pared[i]);

	}
	visual_rampa.setPosition(posicion_rampa);

	//Se modifica el punto de origen para estar en el centro
	for (int i = 0; i < 2; i++) {

		visual_suelo[i].setOrigin(tamanio_final_suelo.x / 2, tamanio_final_suelo.y / 2);
		visual_pared[i].setOrigin(tamanio_final_pared.x / 2, tamanio_final_pared.y / 2);

	}
	visual_bola.setOrigin((radio_bola * PIXELES_POR_METRO), (radio_bola * PIXELES_POR_METRO));
	visual_rampa.setOrigin(tamanio_final_rampa.x / 2, tamanio_final_rampa.y / 2);

	//Se modifica el color de cada figura para diferenciarlas
	visual_suelo[0].setFillColor(Color::Blue);
	visual_suelo[1].setFillColor(Color::Green);
	visual_bola.setFillColor(Color::White);
	visual_pared[0].setFillColor(Color::Cyan);
	visual_pared[1].setFillColor(Color::Cyan);

	visual_rampa.setFillColor(Color::Color(55, 23, 67, 255));
	
	//////////////////////////////////////////////////////////////////////////////////////////
	//Visuales para el Arma / Ca��n
	//////////////////////////////////////////////////////////////////////////////////////////
	/*
	Vector2f tamanio_final_arma_fondo = { (dimensiones_arma_fondo.x * 2) * PIXELES_POR_METRO, (dimensiones_arma_fondo.y * 2) * PIXELES_POR_METRO };
	Vector2f tamanio_final_arma_barril_izq = { (dimensiones_arma_barril.x * 2) * PIXELES_POR_METRO, (dimensiones_arma_barril.y * 2) * PIXELES_POR_METRO };
	Vector2f tamanio_final_arma_barril_der = { (dimensiones_arma_barril.x * 2) * PIXELES_POR_METRO, (dimensiones_arma_barril.y * 2) * PIXELES_POR_METRO };

	//Asigna el tama�o y radio para los componentes del arma
	visual_arma_fondo.setSize(tamanio_final_arma_fondo);
	visual_arma_barril_izq.setSize(tamanio_final_arma_barril_izq);
	visual_arma_barril_der.setSize(tamanio_final_arma_barril_der);
	visual_arma_base.setRadius(radio_base_arma * PIXELES_POR_METRO);

	//Arreglo de vectores que guarda las posiciones f�sicas de los objetos
	//Vector2f posicion_arma[4];
	
	posicion_arma[0] = { cuerpo_arma_fondo->GetPosition().x * PIXELES_POR_METRO, cuerpo_arma_fondo->GetPosition().y * PIXELES_POR_METRO };
	posicion_arma[1] = { cuerpo_arma_barril_izq->GetPosition().x * PIXELES_POR_METRO, cuerpo_arma_barril_izq->GetPosition().y * PIXELES_POR_METRO };
	posicion_arma[2] = { cuerpo_arma_barril_der->GetPosition().x * PIXELES_POR_METRO, cuerpo_arma_barril_der->GetPosition().y * PIXELES_POR_METRO };
	posicion_arma[3] = { cuerpo_arma_base->GetPosition().x * PIXELES_POR_METRO, cuerpo_arma_base->GetPosition().y * PIXELES_POR_METRO };
	
	//Se asignan las posiciones obtenidas para los componentes del arma
	visual_arma_fondo.setPosition(posicion_arma[0]);
	visual_arma_barril_izq.setPosition(posicion_arma[1]);
	visual_arma_barril_der.setPosition(posicion_arma[2]);
	visual_arma_base.setPosition(posicion_arma[3]);

	//Modifica el punto de origen para los componentes del arma
	visual_arma_fondo.setOrigin(tamanio_final_arma_fondo.x / 2, tamanio_final_arma_fondo.y / 2);
	visual_arma_barril_izq.setOrigin(tamanio_final_arma_barril_izq.x / 2, tamanio_final_arma_barril_izq.y / 2);
	visual_arma_barril_der.setOrigin(tamanio_final_arma_barril_der.x / 2, tamanio_final_arma_barril_der.y / 2);

	visual_arma_base.setOrigin((radio_base_arma * PIXELES_POR_METRO), (radio_base_arma * PIXELES_POR_METRO));

	//Aplica el color a cada parte del arma/ca��n
	visual_arma_fondo.setFillColor(Color::Red);
	visual_arma_barril_izq.setFillColor(Color::Red);
	visual_arma_barril_der.setFillColor(Color::Red);
	visual_arma_base.setFillColor(Color::Blue);
	*/
}

//M�todo que permite cambiar la posici�n de un objeto en su parte f�sica y actualiza su visual para encajar con la antes mencionada
void Simulacion::reposicionarObjeto(b2Body* cuerpo, b2Vec2 posicion_nueva) {

	//Aplica la nueva transformaci�n (En este caso solamente posici�n, y no rotaci�n)
	cuerpo->SetTransform(posicion_nueva ,0);

	//Llama a la sincronizaci�n entre f�sicos y visuales
	sincronizarObjetos();

}

//M�todo simple que dibuja una figura rectangular pasada por par�metro. Usa la ventana nativa de la clase
void Simulacion::dibujarRectangulo(RectangleShape figura) {

	//Pasa el contenido suministrado a la ventana del programa para ser renderizado
	ventana->draw(figura);

}

//Variante del m�todo base de dibujar que en su lugar recibe una figura Circular
void Simulacion::dibujarCirculo(CircleShape figura) {

	//Pasa el contenido suministrado a la ventana del programa para ser renderizado
	ventana->draw(figura);

}

//M�todo que permite dibujar una linea recta de dos v�rtices, suministrando ambos puntos adem�s de su color por par�metro
void Simulacion::dibujarLinea(b2Vec2 punto_a, b2Vec2 punto_b, Color color) {

	VertexArray linea(Lines, 2);

	linea[0].position = Vector2f(punto_a.x * PIXELES_POR_METRO, punto_a.y * PIXELES_POR_METRO);
	linea[1].position = Vector2f(punto_b.x * PIXELES_POR_METRO, punto_b.y * PIXELES_POR_METRO);

	linea[0].color = color;
	linea[1].color = color;

	//Pasa el contenido suministrado a la ventana del programa para ser renderizado
	ventana->draw(linea);

}

//Encargado de actualizar la posici�n de los objetos visuales para encajar con la de sus contrapartes f�sicas
void Simulacion::sincronizarObjetos() {

	//Obtiene la posici�n y la convierte a medida por pixel, usada para gr�ficos
	Vector2f posicion_suelo[2];
	Vector2f posicion_bola = { cuerpo_bola->GetPosition().x * PIXELES_POR_METRO, cuerpo_bola->GetPosition().y * PIXELES_POR_METRO };
	Vector2f posicion_pared[2];
	Vector2f posicion_rampa = { cuerpo_rampa->GetPosition().x * PIXELES_POR_METRO, cuerpo_rampa->GetPosition().y * PIXELES_POR_METRO };

	for (int i = 0; i < 2; i++) {

		posicion_suelo[i] = { cuerpo_suelo[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_suelo[i]->GetPosition().y * PIXELES_POR_METRO };
		posicion_pared[i] = { cuerpo_pared[i]->GetPosition().x * PIXELES_POR_METRO, cuerpo_pared[i]->GetPosition().y * PIXELES_POR_METRO };

	}

	//Asigna las nuevas posiciones a cada cuerpo visual
	visual_bola.setPosition(posicion_bola);
	for (int i = 0; i < 2; i++) {

		visual_suelo[i].setPosition(posicion_suelo[i]);
		visual_pared[i].setPosition(posicion_pared[i]);

	}
	visual_rampa.setPosition(posicion_rampa);

	///////////////////////////////////////////////////////////////////////////////////////
	/*
	//Obtiene la posici�n de los componentes del arma y la convierte a pixel
	Vector2f posicion_arma[4];

	posicion_arma[0] = { cuerpo_arma_fondo->GetPosition().x * PIXELES_POR_METRO, cuerpo_arma_fondo->GetPosition().y * PIXELES_POR_METRO };
	posicion_arma[1] = { cuerpo_arma_barril_izq->GetPosition().x * PIXELES_POR_METRO, cuerpo_arma_barril_izq->GetPosition().y * PIXELES_POR_METRO };
	posicion_arma[2] = { cuerpo_arma_barril_der->GetPosition().x * PIXELES_POR_METRO, cuerpo_arma_barril_der->GetPosition().y * PIXELES_POR_METRO };
	posicion_arma[3] = { cuerpo_arma_base->GetPosition().x * PIXELES_POR_METRO, cuerpo_arma_base->GetPosition().y * PIXELES_POR_METRO };

	visual_arma_fondo.setPosition(posicion_arma[0]);
	visual_arma_barril_izq.setPosition(posicion_arma[1]);
	visual_arma_barril_der.setPosition(posicion_arma[2]);
	visual_arma_base.setPosition(posicion_arma[3]);
	*/
	////////////
	//ROTACI�N//
	////////////

	//Guarda la rotaci�n en radianes de la rampa
	float angulos_rampa = cuerpo_rampa->GetAngle() * (180.0f / b2_pi);

	//Asigna la rotaci�n al cuerpo visual
	visual_rampa.setRotation(angulos_rampa);
	/*
	//Almacena la rotaci�n de los cuerpos f�sicos, pasandolas desde radianes a grados
	float angulos_arma[3];
	angulos_arma[0] = cuerpo_arma_fondo->GetAngle() * (180.0f / b2_pi);
	angulos_arma[1] = cuerpo_arma_barril_izq->GetAngle() * (180.0f / b2_pi);
	angulos_arma[2] = cuerpo_arma_barril_der->GetAngle() * (180.0f / b2_pi);

	//Usa la rotaci�n convertida para actualizar las figuras visuales
	visual_arma_fondo.setRotation(angulos_arma[0]);
	visual_arma_barril_izq.setRotation(angulos_arma[1]);
	visual_arma_barril_der.setRotation(angulos_arma[2]);
	*/
}

//M�todo DEBUG: Usado para mostrar en consola la posici�n de los cuerpos de la pantalla, tanto para la variante f�sica como la visual
void Simulacion::depurarPosicionCuerpos() {

	//Env�a la posici�n f�sica y visual de la bola a consola
	cout << "Posicion Bola Fisica: " << cuerpo_bola->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_bola->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Bola Visual: " << visual_bola.getPosition().x << ", " << visual_bola.getPosition().y << endl;

	//Env�a la posici�n f�sica y visual de las paredes, techo, suelo y obst�culos usando un bucle for de 2 iteraciones
	for (int i = 0; i < 2; i++) {

		cout << "Posicion Suelo Fisico " << i << "; " << cuerpo_suelo[i]->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_suelo[i]->GetPosition().y * PIXELES_POR_METRO << endl;
		cout << "Posicion Suelo Visual " << i << "; " << visual_suelo[i].getPosition().x << ", " << visual_suelo[i].getPosition().y << endl;

		cout << "Posicion Pared Fisica " << i << ": " << cuerpo_pared[i]->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_pared[i]->GetPosition().y * PIXELES_POR_METRO << endl;
		cout << "Posicion Pared Visual " << i << ": " << visual_pared[i].getPosition().x << ", " << visual_pared[i].getPosition().y << endl;

	}
	/*
	//Env�a la posici�n f�sica y visual del arma completa a consola
	cout << "Posicion Arma Fisica [Fondo]: " << cuerpo_arma_fondo->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_arma_fondo->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Arma Visual [Fondo]: " << visual_arma_fondo.getPosition().x << ", " << visual_arma_fondo.getPosition().y << endl;

	cout << "Posicion Arma Fisica [Barril Izquierdo]: " << cuerpo_arma_barril_izq->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_arma_barril_izq->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Arma Visual [Barril Izquierdo]: " << visual_arma_barril_izq.getPosition().x << ", " << visual_arma_barril_izq.getPosition().y << endl;

	cout << "Posicion Arma Fisica [Barril Derecho]: " << cuerpo_arma_barril_der->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_arma_barril_der->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Arma Visual [Barril Derecho]: " << visual_arma_barril_der.getPosition().x << ", " << visual_arma_barril_der.getPosition().y << endl;

	cout << "Posicion Arma Fisica [Base]: " << cuerpo_arma_base->GetPosition().x * PIXELES_POR_METRO << ", " << cuerpo_arma_base->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "Posicion Arma Visual [Base]: " << visual_arma_base.getPosition().x << ", " << visual_arma_base.getPosition().y << endl;
	*/
}